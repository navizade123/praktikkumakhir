import React from "react";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import {Main} from './Components/Main';
import {Home} from './Components/home'
import Navbar from "./Components/Navbar";

function App() {
  return (
    <Router>
      <Navbar /> <hr/>
      <Routes>
        <Route index="/" element={<Home />} />
        <Route path="main" element={<Main />} />
      </Routes>
    </Router>

    

  );
}

export default App;