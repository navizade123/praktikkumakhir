import React from "react";
import { Link } from "react-router-dom";
import icon from './Logo.png'
import './navbar.css'

const Navbar = () => {
  return (
    <nav>
      <img src={icon}/>
      <ul>
        <li>
        <Link to="">Napid Store</Link>
        </li>
        <li>
          <Link to="main">Toko</Link>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;