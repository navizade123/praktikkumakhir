import React from "react";

export function Home() {
  return (
    <div>
      <h1>SELAMAT DATANG !!!</h1>
      <h3>SILAHKAN KLIK TOKO DI POJOK KANAN ATAS !!!</h3>
    </div>
  );
}

export default Home;
