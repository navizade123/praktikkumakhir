import React, { useEffect, useState } from "react";
import './main.css';

export function Main() {
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch("https://furniture-dummy-data-api.vercel.app/data")
      .then(response => response.json())
      .then((json) => setData(json.payload));
  }, []);

  if (!data) {
    return <p>Loading...</p>;
  }

  return (
    <div>
      <h2>Happy Shopping !!!</h2>
      <ul>
        {data.map(item => (
          <div className="List" key={item.id}>
            <li>{item.name}</li><br />
            <li>Harga : Rp {item.price} </li><br />
            <li>Deskripsi :<br /> {item.description}</li><br />
            <button>Beli Disini</button>
          </div>
        ))}
      </ul>
    </div>
  );
}


